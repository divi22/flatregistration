package ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import bean.FlatRegistrationDto;
import exception.FlatException;
import service.FlatRegistrationServiceImpl;
import service.IFlatRegistrationService;

public class Client {
	public static void main(String[] args) throws FlatException {
		do {
			List<Integer> ownerList =new ArrayList<Integer>();
			IFlatRegistrationService service= new FlatRegistrationServiceImpl();
			Scanner sc= new Scanner(System.in);
			System.out.println("1)Register flat");
			System.out.println("2)Display Flat registartion details");
			System.out.println("3)Exit");
			int option = 0;
			try {
				option = sc.nextInt();
			} catch (InputMismatchException e1) {
				// TODO Auto-generated catch block
				System.out.println("Please enter an integer value");
			}
			switch(option)
			{
			case 1:
				System.out.println("Existing owner Ids are:");
				 ownerList=service.getAllOwnerIds();
				 System.out.println(ownerList);
				 FlatRegistrationDto flatRegister= new FlatRegistrationDto();
				flatRegister = getAllRegistrationDetails();
				try {
					flatRegister = service.registerFlat(flatRegister);
					System.out.println("Flat successfully registered");
					System.out.println("Registration Id:"+ flatRegister.getRegistrationId());
					System.out.println("Flat Type "+flatRegister.getFlatType() +"BHK");
					System.out.println("Flat area"+ flatRegister.getSquareFeet());
					System.out.println("Rent amount: Rs. " + flatRegister.getRentAmount());
					System.out.println("Deposit Amount: Rs. "+flatRegister.getDepositAmount());
				} catch (FlatException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}

				break;
			case 2:
				Map<Integer,FlatRegistrationDto> flatDetails= new HashMap<>();
				flatDetails= service.getRegistrationDetails();
				System.out.println("ID:"+flatDetails.keySet());
				if(flatDetails.isEmpty())
				{
					System.out.println("No registration done");
				}
				else
				{
					Set<Integer> keys = flatDetails.keySet();  
					for(Integer i: keys)
					{
						FlatRegistrationDto c=new FlatRegistrationDto();
						c=flatDetails.get(i);
						System.out.println("OwnerID:"+c.getFlatOwnerId());
						System.out.println("Flattype:"+c.getFlatType());

						System.out.println("Deposit Amount:" + c.getDepositAmount());  
						System.out.println("Registration id:"+c.getRegistrationId());
						System.out.println("RentAmount:"+c.getRentAmount());
						System.out.println("SquareFeet"+c.getSquareFeet());
						System.out.println("------------------------------");

					}
				}

				break;
			case 3:
				System.exit(0);
				break;
			default:
				System.out.println("please enter correct input");
				break;
			}



		}while(true);
	}

	public static FlatRegistrationDto getAllRegistrationDetails()
	{
		FlatRegistrationDto fr= new FlatRegistrationDto();
		Scanner sc= new Scanner(System.in);

		System.out.println("please enter your owner id from above list:");
		try {
			int ownerId= sc.nextInt();
			fr.setFlatOwnerId(ownerId);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("please enter an integer value");
		}

		System.out.println("Enter flat type(1-1BHK,2-2BHK)");
		try {
			int flatType= sc.nextInt();
			fr.setFlatType(flatType);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("please enter an integer value");
		}

		System.out.println("Enter flat area in sq. ft");
		try {
			int squareFeet= sc.nextInt();
			fr.setSquareFeet(squareFeet);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("please enter an integer value");
		}

		System.out.println("Enter desired rent amount Rs. ");
		try {
			int rentAmount=sc.nextInt();
			fr.setRentAmount(rentAmount);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("please enter an integer value");
		}

		System.out.println("Enter desired deposit amount Rs. ");
		try {
			int depositAmount= sc.nextInt();
			fr.setDepositAmount(depositAmount);
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("please enter an integer value");
		}

		return fr;
	}

}
